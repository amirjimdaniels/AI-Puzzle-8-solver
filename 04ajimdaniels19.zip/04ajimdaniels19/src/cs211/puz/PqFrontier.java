package cs211.puz;

/**
 * Student uses a priority queue with the appropriate comparator 
 * in order to give priority needed for informed searches.
 * 
 * @author 
 *
 */
public class PqFrontier implements Frontier {

	@Override
	public void addNode(TreeNode n) {
		// TODO replace this stub with your code
	}

	@Override
	public TreeNode removeNode() {
		// TODO replace this stub with your code
		return null;
	}

	@Override
	public boolean containsState(PuzState state) {
		// TODO replace this stub with your code
		return false;
	}

	@Override
	public TreeNode findNode(PuzState state) {
		// TODO replace this stub with your code
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO replace this stub with your code
		return false;
	}



}
