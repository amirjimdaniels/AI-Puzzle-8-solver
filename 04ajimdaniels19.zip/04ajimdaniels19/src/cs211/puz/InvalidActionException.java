package cs211.puz;

public class InvalidActionException extends Exception {

	public InvalidActionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
